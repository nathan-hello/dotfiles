/*
 * Primary color hues:
 *  blue:  0 degrees
 *  red:   120 degrees
 *  green: 240 degrees
 */
int hls_to_rgb(int hue, int lum, int sat);
