#include <arpa/inet.h>

static void updatexy(void);
static XImage *loadff(const char *);
static void bginit();
static void reload_image();
