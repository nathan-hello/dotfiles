void toggle_winmode(int);
void keyboard_select(const Arg *);