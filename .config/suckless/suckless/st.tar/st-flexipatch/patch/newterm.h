void newterm(const Arg *);
static char *getcwd_by_pid(pid_t pid);