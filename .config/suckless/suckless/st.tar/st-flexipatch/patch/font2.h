static int xloadsparefont(FcPattern *, int);
static void xloadsparefonts(void);