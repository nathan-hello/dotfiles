void keyboard_select(const Arg *);
void searchforward(const Arg *);
void searchbackward(const Arg *);
