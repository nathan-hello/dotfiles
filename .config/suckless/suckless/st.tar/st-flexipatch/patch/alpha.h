static float clamp(float value, float lower, float upper);
static void changealpha(const Arg *);
#if ALPHA_FOCUS_HIGHLIGHT_PATCH
static void changealphaunfocused(const Arg *arg);
#endif // ALPHA_FOCUS_HIGHLIGHT_PATCH
