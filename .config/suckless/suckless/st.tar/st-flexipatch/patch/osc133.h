static void scrolltoprompt(const Arg *);
