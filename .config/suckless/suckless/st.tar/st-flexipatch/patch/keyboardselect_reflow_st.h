void kbds_drawstatusbar(int y);
void kbds_pasteintosearch(const char *, int, int);
int kbds_isselectmode(void);
int kbds_issearchmode(void);
int kbds_drawcursor(void);
int kbds_keyboardhandler(KeySym, char *, int, int);
