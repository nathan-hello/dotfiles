void toggle_winmode(int);
int trt_kbdselect(KeySym, char *, int);