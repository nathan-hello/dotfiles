void externalpipe(const Arg *);
#if EXTERNALPIPEIN_PATCH
void externalpipein(const Arg *);
#endif // EXTERNALPIPEIN_PATCH